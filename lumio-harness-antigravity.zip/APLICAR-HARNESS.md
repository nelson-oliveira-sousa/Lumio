# Como aplicar o harness (Antigravity)

Este arquivo é só para você: não vai para o repositório.

## Onde fica cada coisa
| Arquivo | Para quê | Card |
|---|---|---|
| `AGENTS.md` | regras do workspace (o Antigravity carrega sozinho) | HAR-01 |
| `docs/arquitetura.md`, `docs/adr/` | arquitetura e decisões | HAR-02 |
| `docs/padroes.md` | padrões com arquivo canônico | HAR-04 |
| `docs/glossario.md` | nomes do domínio | HAR-05 |
| `docs/antigravity-permissoes.md` + `.agents/hooks/comandos.rb` | permissões | HAR-06 |
| `.agents/hooks/formatacao.rb` + `lint-pendente.rb` | lint devolvido ao agente | HAR-07 |
| `.agents/hooks/protecao.rb` | segredos, migrations, package_todo | HAR-08 |
| `scripts/proteger-main.sh` | proteção da main | HAR-09 |
| `make/harness.mk`, `scripts/testes-alterados.sh`, `spec/support/tenant_helpers.rb` | testes focados | HAR-10 |
| `.agents/skills/` | card, revisar, migration-tenant, novo-pack, registrar-licao, codigo-tenant | HAR-14 |
| `.agents/agents/revisor.md` | subagente revisor | HAR-15 |
| `backlog/_modelo.md`, `.github/pull_request_template.md` | templates | HAR-16 |
| `docs/fluxo-agente.md` | fluxo | HAR-17 |
| `backlog/`, `scripts/backlog.rb` | backlog no repositório | HAR-18 |
| `docs/licoes.md` | ciclo de aprendizado | HAR-19 |

Os modelos de README/AGENTS.md por pack (HAR-03) estão em `.agents/skills/novo-pack/modelos/`.

## Instalar
1. Copie **todo** o conteúdo desta pasta para a raiz do repositório, incluindo as pastas ocultas `.agents` e `.github` (no gerenciador de arquivos, `Ctrl+H` mostra ocultos).
2. `chmod +x .agents/hooks/*.rb scripts/*.sh scripts/*.rb`
3. Confira que `ruby` está no PATH: os hooks são Ruby puro, sem gems.
4. Abra a pasta do repositório como workspace no Antigravity.
5. Em **… → Customizations**, confira:
   - **Rules**: `AGENTS.md`
   - **Skills**: card, revisar, migration-tenant, novo-pack, registrar-licao, codigo-tenant
   - **Hooks**: lumio-protecao-arquivos, lumio-comandos, lumio-formatacao, lumio-lint-pendente
6. Configure as permissões da interface com `docs/antigravity-permissoes.md`.
7. Teste um bloqueio: peça ao agente "mostre o conteúdo do .env". Ele deve receber a mensagem do harness.
8. `scripts/backlog.rb validar` e `scripts/backlog.rb liberados`.

Depois dos cards de produto:
- LUM-02: adicione `include make/*.mk` no Makefile
- LUM-04: rode `scripts/proteger-main.sh` com o nome do job de CI
- LUM-08: carregue `spec/support/` no `rails_helper.rb`

## Limitações conhecidas
- **Subagente customizado**: a documentação lista para o Antigravity 2.0 e o CLI. Se a sua versão do IDE não tiver, a skill `revisar` faz o agente principal seguir o mesmo roteiro, sem editar arquivos.
- **Caminho dos hooks**: o `hooks.json` usa caminhos relativos à raiz do workspace (`./.agents/hooks/...`). Se aparecerem como falhos no painel, troque por caminhos absolutos.
- **Permissões** não são versionadas no repositório: por isso os hooks de comando existem.

## Decisões para confirmar
- Nomes dos 9 packs e o grafo de dependências (`AGENTS.md`, `docs/arquitetura.md`).
- Tenant = organização contratante (ADR-0002).
- `Tenancy::Api.com_tenant` no lugar de `com_campo` (card LUM-08).
- Migrations de tenant em `db/tenant_migrate/`.
